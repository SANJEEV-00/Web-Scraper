const axios = require('axios');
const cheerio = require('cheerio');
const csvWriter = require('csv-write-stream');
const fs = require('fs');

// URL to scrape
const url = 'https://news.ycombinator.com/';

// Function to scrape data
const scrapeData = async () => {
  try {
    console.log('Starting the scrape...');

    // Fetch the webpage HTML
    const response = await axios.get(url);

    // Check if the response was successful
    if (response.status !== 200) {
      console.log('Error: Failed to fetch the webpage');
      return;
    }

    console.log('Web page fetched successfully, parsing data...');

    // Parse the HTML with Cheerio
    const $ = cheerio.load(response.data);

    // Create the CSV writer stream
    const writer = csvWriter({ headers: ['Rank', 'Title', 'Link'] });
    writer.pipe(fs.createWriteStream('headlines.csv'));

    // Scrape data from the webpage
    let count = 1; // To track the rank
    $('.athing').each((index, element) => {
      const title = $(element).find('.storylink').text(); // Get the title
      const link = $(element).find('.storylink').attr('href'); // Get the link

      // Log data to check if it's being extracted correctly
      console.log(`Rank: ${count}, Title: ${title}, Link: ${link}`);

      // Write to CSV file
      writer.write([count, title, link]);

      count++;
    });

    // Close the CSV file after writing
    writer.end();
    console.log('Data has been saved to headlines.csv');
  } catch (error) {
    console.error('Error scraping the website:', error);
  }
};

// Call the function to start scraping
scrapeData();
